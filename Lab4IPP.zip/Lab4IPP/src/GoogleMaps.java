public class GoogleMaps extends API {

  public String sendData() {
  return null;
  }

}