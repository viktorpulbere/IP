import java.util.List;
import java.util.Vector;

public class Application {

  public String filter;

  public int clusterSize;

  public String statType;

  public boolean isLoggedIn;

  public List<String> Language;


  public Vector  myAdministrator;

  public Vector  myUser;
    public API myAPI;

  public String sendReq() {
  return null;
  }

  public String getFilter() {
  return null;
  }

  public void cluster() {
  }

  public void color() {
  }

  public void statGraph() {
  }

  public void clusterSize() {
  }

  public void parseFilter() {
  }

  public void getAuthorization() {
  }

}