public class Twitter extends API {

  public String sendData() {
  return null;
  }

  public void filterTweets( String tweet) {
  }

}