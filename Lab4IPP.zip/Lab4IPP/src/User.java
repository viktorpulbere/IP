public class User {

    public Application myApplication;

  public void viewData( String View) {
  }

  public void applyFilter( String Apply) {
  }

}