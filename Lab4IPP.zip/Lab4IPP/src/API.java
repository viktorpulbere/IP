public class API {

    public Application myApplication;

  public String sendData() {
  return null;
  }

  public String getRequest() {
  return null;
  }

}