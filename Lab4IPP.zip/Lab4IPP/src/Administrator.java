public class Administrator {

    public Application myApplication;

  public void manageLang( String lang) {
  }

  public void adjustCluster( int clusterSize) {
  }

  public void authorize() {
  }

}