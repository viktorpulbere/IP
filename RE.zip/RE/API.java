// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/13/2019 08:45:34
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   API.java


public class API
{

    public API()
    {
    }

    public String sendData()
    {
        return null;
    }

    public String getRequest()
    {
        return null;
    }

    public Application myApplication;
}