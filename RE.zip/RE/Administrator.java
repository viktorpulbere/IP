// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/13/2019 08:46:03
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Administrator.java


public class Administrator extends User
{

    public Administrator()
    {
    }

    public void manageLang(String s)
    {
    }

    public void adjustCluster(int i)
    {
    }

    public void authorize()
    {
    }

    public Application myApplication;
}