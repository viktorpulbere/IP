// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/13/2019 08:44:42
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   GoogleMaps.java


public class GoogleMaps extends API
{

    public GoogleMaps()
    {
    }

    public String sendData()
    {
        return null;
    }
}