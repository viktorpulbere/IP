// Decompiled by DJ v3.10.10.93 Copyright 2007 Atanas Neshkov  Date: 3/13/2019 08:45:20
// Home Page: http://members.fortunecity.com/neshkov/dj.html  http://www.neshkov.com/dj.html - Check often for new version!
// Decompiler options: packimports(3) 
// Source File Name:   Application.java

import java.util.List;
import java.util.Vector;

public class Application
{

    public Application()
    {
    }

    public String sendReq()
    {
        return null;
    }

    public String getFilter()
    {
        return null;
    }

    public void cluster()
    {
    }

    public void color()
    {
    }

    public void statGraph()
    {
    }

    public void clusterSize()
    {
    }

    public void parseFilter()
    {
    }

    public void getAuthorization()
    {
    }

    public String filter;
    public int clusterSize;
    public String statType;
    public boolean isLoggedIn;
    public List Language;
    public Vector myAdministrator;
    public Vector myUser;
    public API myAPI;
}